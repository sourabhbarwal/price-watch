// components/ClientPriceHistoryChart.js

"use client";

import PriceHistoryChart from "./PriceHistoryChart";

export default function ClientPriceHistoryChart({ data }) {
  return <PriceHistoryChart data={data} />;
}
