export const NotificationModel = {
  id: "",
  type: "PRICE_DROP", // PRICE_DROP | PREDICTION | SYSTEM
  title: "",
  message: "",
  productId: "",
  read: false,
  createdAt: "",
};
