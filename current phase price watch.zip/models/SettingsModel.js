export const SettingsModel = {
  theme: "system", // light | dark | system
  currency: "INR",
  autoTrackFromExtension: true,
  emailAlerts: true,
  pushNotifications: true,
};
