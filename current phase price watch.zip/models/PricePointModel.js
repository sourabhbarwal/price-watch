export const PricePointModel = {
  date: "", // ISO string
  price: 0,
};
