// data/userTargets.js

export const userTargets = {
  p1: 21000,
  p2: 27000,
  // p3 has no target yet
};
