// data/priceHistory.js

export const priceHistory = {
  p1: [
    { date: "Dec 10", price: 22999 },
    { date: "Dec 12", price: 22499 },
    { date: "Dec 14", price: 21999 },
    { date: "Dec 16", price: 21499 },
    { date: "Dec 18", price: 21999 },
  ],
  p2: [
    { date: "Dec 10", price: 29999 },
    { date: "Dec 12", price: 29499 },
    { date: "Dec 14", price: 28999 },
    { date: "Dec 16", price: 27999 },
    { date: "Dec 18", price: 28999 },
  ],
  p3: [
    { date: "Dec 10", price: 31999 },
    { date: "Dec 12", price: 31499 },
    { date: "Dec 14", price: 30999 },
    { date: "Dec 16", price: 30499 },
    { date: "Dec 18", price: 29999 },
  ],
};
